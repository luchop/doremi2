<?php if ( ! defined('BASEPATH')) exit('No se permite acceso directo.');

class Usuario extends CI_Controller {

    private $Menu;
    
    function __construct() {
        parent::__construct();
		$this->Menu = ObtieneVista($this->session->userdata('TipoUsuario'));
    }

    function Index() {
        $data['VistaMenu'] = $this->Menu;
        $data['VistaPrincipal'] = 'vista_nula';
        $this->load->view('vista_maestra', $data);
    }
    function Nuevo(){
       
        $this->load->model('Modelo_usuario');
        $data['ComboPerfil'] = $this->Modelo_usuario->ComboPerfil();
        
        $data['VistaMenu'] = $this->Menu;
        $data['Tipo'] = 'nuevo';
        $data['VistaPrincipal'] = 'vista_nuevo_usuario';
        $this->load->view('vista_maestra', $data);
        
    }
    function Editar($codigo){
       
        $this->load->model('Modelo_usuario');
        $this->load->model('Modelo_formulario','modelo_formulario');
        
        $data['Fila'] = $this->Modelo_usuario->GetXId($codigo);
        //print_r($data['Fila']);
        $data['VistaMenu'] = $this->Menu;
        $data['Tipo'] = 'editar';
        $data['ComboPerfil'] = $this->Modelo_usuario->ComboPerfil();
        $data['ComboCarreras']=$this->modelo_formulario->ComboCarrera("CodCarrera",0 );
        $data['VistaPrincipal'] = 'vista_editar_usuario';
        $this->load->view('vista_maestra', $data);
        
    }
    function Guardar() {
        $this->load->model('Modelo_usuario');
		if($this->input->post('Tipo')=="nuevo"){
			$this->Modelo_usuario->InsertPersona($this->input->post('Paterno'),$this->input->post('Materno'),$this->input->post('Nombres'),$this->input->post('Telefono'),$this->input->post('Celular'),$this->input->post('Email'));
			$this->Modelo_usuario->Insert($this->input->post('NombreUsuario'), $this->input->post('Clave'), $this->input->post('CodPerfil'));
			//$data['Mensaje'] = 'Se ha registrado un nuevo Usuario.';
			//$data['VistaPrincipal'] = 'vista_listado_usuarios';
			//$this->load->view('vista_maestra', $data);
			$this->Listado();
		}
		
		if($this->input->post('Tipo')=="editar"){
			$this->Modelo_usuario->UpdatePersona($this->input->post('CodPersona'),$this->input->post('Paterno'),$this->input->post('Materno'),$this->input->post('Nombres'),$this->input->post('Telefono'),$this->input->post('Celular'),$this->input->post('Correo'));
			$this->Modelo_usuario->Update($this->input->post('CodUsuario'),  $this->input->post('CodPersona'),$this->input->post('NombreUsuario'), $this->input->post('Clave'), $this->input->post('CodPerfil'));
			$this->Listado();
		}      
    }
    
    function Listado(){
        $this->load->model('Modelo_usuario');
        $registros = $this->Modelo_usuario->GetAll();
        $this->load->library('table');
                $this->table->set_empty("&nbsp;");
                $this->table->set_heading('No.', 'Nombre Completo', 'Nombre Usuario', 'Perfil', 'Editar','Eliminar');
                $aux = array('table_open' => '<table class="tablaseleccion">');
                $this->table->set_template($aux);
                $i = 0;
                
        foreach ($registros->result() as $registro)
         $this->table->add_row(++$i, $registro->Nombres." ".$registro->Paterno." ".$registro->Materno, $registro->NombreUsuario, $registro->Perfil, anchor("index.php/Usuario/Editar/" . $registro->CodUsuario, 'Modificar '),anchor("index.php/Usuario/Eliminar/" . $registro->CodUsuario, 'Eliminar',array('class'=>'elimina','onclick'=>"return confirm('Realmente desea borrar este registro?')")));
         
        $data['Tabla'] = $this->table->generate();
        $data['VistaMenu'] = $this->Menu;
        $data['VistaPrincipal'] = 'vista_listado_usuarios';
        $this->load->view('vista_maestra', $data);
                
        
    }
    function ListadoUsuarioCarrera(){
        $this->load->model('Modelo_usuario');
        $registros = $this->Modelo_usuario->GetUsuarioCarrera($_POST['CodUsuario']);
        $tabla="<table>";
        $tabla.="<tr><th>#</th><th>Carrera</th><th>Eliminar</th><tr>";
                $i=0;
        foreach ($registros->result() as $registro)
         $tabla.="<tr><td>".++$i."</td><td>".$registro->Nombre."</td><td><a href='#' onclick='Eliminar(".$registro->CodUsuarioCarrera.")'>Eliminar</a></td><tr>";
        $tabla.="</table>"; 
        echo $tabla;
    }
    function InsertUsuarioCarrera() {
        $this->load->model('Modelo_usuario');
        $this->Modelo_usuario->InsertUsuarioCarrera($_POST['CodUsuario'],$_POST['CodCarrera']);
            $this->ListadoUsuarioCarrera($_POST['CodUsuario']);
    }
    
    function EliminarUsuarioCarrera() {
        $this->load->model('Modelo_usuario');
        $this->Modelo_usuario->DeleteUsuarioCarrera($_POST['CodUsuarioCarrera']);
            $this->ListadoUsuarioCarrera($_POST['CodUsuario']);
    }
    
    function Eliminar($CodUsuario) {
        $this->load->model('Modelo_usuario');
        $this->Modelo_usuario->Disable($CodUsuario);
            $this->Listado();
    }
    
    function Verificacion() {
        $this->load->model('Modelo_usuario');
        if($this->Modelo_usuario->GetXUsuario($_POST['Usuario']))
            echo "1";
        else 
            echo "0";
    }
}
?>
