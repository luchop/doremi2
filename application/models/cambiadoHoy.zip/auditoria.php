<?php if ( ! defined('BASEPATH')) exit('No se permite acceso directo.');

class Auditoria extends CI_Controller {

    function __construct() {
        parent::__construct();
		//$this->load->model('Modelo_usuario', '', TRUE);
    }

    function Index() {
	$data['VistaMenu'] = 'vista_menu';
	$data['VistaPrincipal'] = 'vista_nula';
        $this->load->view('vista_maestra', $data);
    }
    function Listado(){
       
        $this->load->model('modelo_auditoria',"auditoria");
        $tabla="<table><tr><td>Fecha</td><td>Cambio</td></tr>";
        $registros = $this->auditoria->GetAllXCodPersona($_POST["CodPersona"]);
        //$registros = $this->auditoria->GetAllXCodPersona('1');
        foreach ($registros->result() as $registro)
        {
            $tabla.="<tr>
                <td>".$registro->Fecha."</td><td>".$registro->Consulta."</td>
                </tr>";
        }
        $tabla.="</tabla>";
        echo $tabla;
    }
    function Busqueda(){
       
        $data['VistaMenu'] = 'vista_menu';
        $data['VistaPrincipal'] = 'vista_auditoria';
        $this->load->view('vista_maestra', $data);
        
    }
    
}
?>
